This is where the developer will code what process should be executed based on what action received by filling also the mapping.json file.
