This will be a falsk rest http app. But we will later add some other capabilities: TCP, UDP, Telnet.
